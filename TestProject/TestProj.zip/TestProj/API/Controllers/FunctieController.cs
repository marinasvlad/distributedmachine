﻿using Microsoft.AspNetCore.Mvc;

namespace API;


[ApiController]
[Route("api/[controller]")]
public class FunctieController : ControllerBase
{
    [HttpGet("{nume}")]
    public ActionResult<string> Functie(string nume)
    {
        string result = nume + " este smecher"; 
        return Ok(result);
    }
}
